exports.menu = (prefix, emote) => {
    return `         🔮 *BOT UPDATE RUNNING*

        
✗⃝🌍 _${prefix}topbalance_
✗⃝🌍 _${prefix}glimit_
✗⃝🌍 _${prefix}buylimit_ <angka>
✗⃝🌍 _${prefix}buyglimit_ <angka>
✗⃝🌍 _${prefix}cekprefix_


       🕊️ *TOOLS SECTION DISPLAY*
       
✗⃝🕊️ _${prefix}sticker_
✗⃝🕊️ _${prefix}swm_
✗⃝🕊️ _${prefix}take_
✗⃝🕊️ _${prefix}kontak_ nomor|nama
✗⃝🕊️ _${prefix}toimg_
✗⃝🕊️ _${prefix}attp text_
✗⃝🕊️ _${prefix}amongus_ text
✗⃝🕊️ _${prefix}codetext_ text
✗⃝🕊️ _${prefix}translate_ kodebahasa teks/reply


        🛰️ *MODERATION GRUP*

✗⃝🛰️ _${prefix}antilink_
✗⃝🛰️ _${prefix}antivo_
✗⃝🛰 ️_${prefix}welcome_
✗⃝🛰 ️_${prefix}left_
✗⃝🛰 ️_${prefix}antibadword_
✗⃝🛰 ️_${prefix}listbadword_
✗⃝🛰️ _${prefix}addbadword_
✗⃝🛰 ️_${prefix}delbadword_
✗⃝🛰️ _${prefix}tictactoe
 
 
         🔮 *DOWNLOADER*
         
✗⃝🔮 _${prefix}ytmp4_ url
✗⃝🔮 _${prefix}ytmp3_ url
✗⃝🔮 _${prefix}igdl_ url
✗⃝🔮 _${prefix}fbdl_ url
✗⃝🔮 _${prefix}gogimage_ query
✗⃝🔮 _${prefix}tiktok_ url
✗⃝🔮 _${prefix}yts_ query
✗⃝🔮 _${prefix}play_ query
✗⃝🔮 _${prefix}playmp4_ query
✗⃝🔮 _${prefix}igstalk_ username
✗⃝🔮 _${prefix}ghstalk_ username

           
           💫 *AGAMA ISLAM*
        
✗⃝💫 _${prefix}listsurah_
✗⃝💫 _${prefix}asmaulhusna_
✗⃝💫 _${prefix}surah_
✗⃝💫 _${prefix}alkitab_
✗⃝💫 _${prefix}randomquran q
✗⃝💫 _${prefix}jadwalsholat_
✗⃝💫 _${prefix}nabi_
✗⃝💫 _${prefix}hadist_


✗⃝👾 _*NEW UPDATE*_

*Saya Di Sini Fax Botz Ingin menyempaikan Tentang Bot Ini*
*Bot Ini Masih Dalam Pengembangan Dan Akses*
*Bot Ini Lagi Di Tambahin Fitur Yang Belum Kami Akses*

  
bot ini merupakan program open-source yang ditulis menggunakan Javascript.

Dengan menggunakan bot ini maka anda setuju dengan Syarat dan Kondisi sebagai berikut:
- bot tidak menyimpan data anda di server kami.
- bot tidak *bertanggung jawab* atas sticker yang anda buat dari bot ini serta video, gambar,text maupun data lainnya yang anda dapatkan dari bot ini.
- bot *tidak boleh* digunakan untuk layanan yang bertujuan/berkontribusi dalam: 
        • seks / perdagangan manusia
    • perjudian
        • perilaku adiktif yang merugikan 
    • kejahatan
        • kekerasan (kecuali jika diperlukan untuk melindungi keselamatan publik)
    • pembakaran hutan / penggundulan hutan
        • *ujaran kebencian atau diskriminasi berdasarkan usia, jenis kelamin, identitas gender, ras, seksualitas, agama, kebangsaan*

- Adapun larangan bot itu sendiri sebagai berikut:
-     • Dilarang melakukan Spamming pada bot dengan maksud apapun
    • Dilarang melakukan video call pada bot dengan maksud apapun
    •     • Dilarang melakukan Telp pada bot dengan maksud apapun
    • Dilarang untuk melakukan abuse Command bot dengan maksud apapun
    • Melanggar larangan di atas? anda akan terkena _Auto Block_ 
    • Req UnBlock? bisa Chat wa *Creator*
Best regard, *Fax Botz*.`
}
exports.ownerr = (prefix, owner, emote) => {
     return `❐──➨ *「 𝑶𝒘𝒏𝒆𝒓 」*
✗⃝🌍 _> eval_
✗⃝🌍 _$ execot_
✗⃝🌍 _self_
✗⃝🌍 _${prefix}public_
✗⃝🌍 _${prefix}restart_
✗⃝🌍 _${prefix}off_
✗⃝🌍 _${prefix}addupdate_
✗⃝🌍 _${prefix}resetlimit_
✗⃝🌍 _${prefix}setpp_
✗⃝🌍 _${prefix}setname_
✗⃝🌍 _${prefix}setbio_
✗⃝🌍 _${prefix}setprefix_
✗⃝🌍 _${prefix}bc_
✗⃝🌍 _${prefix}bcbuton_
✗⃝🌍 _${prefix}block_
✗⃝🌍 _${prefix}unblock_
✗⃝🌍 _${prefix}ban_
✗⃝🌍 _${prefix}unban_
✗⃝🌍 _${prefix}clearall_
✗⃝🌍 _${prefix}givelimit_
✗⃝🌍 _${prefix}giveglimit_
✗⃝🌍 _${prefix}exif_ nama|author
✗⃝🌍 _${prefix}addsewa_ link waktu
✗⃝🌍 ${prefix}delsewa_ idgroup
✗⃝🌍 _${prefix}addprem_
✗⃝🌍 _${prefix}delprem_`}

exports.infobot = (botName, pendaftar) => {
     return `*Information Bot WhatsApp*
• *Bot name* : _${botName}_
• *Number* :  @62813345116361
• *owner name* : _Reza Dinata_
• *Number* : @6283193164235
• *Total users* : ${pendaftar.length} _Users_
• *Github* : https://github.com/Rezadinata
`}


exports.help = (ucapanWaktu, timeWib, timeWita, timeWit, sender, email, owner, ig) => {
     return `${ucapanWaktu} @${sender.split("@")[0]} 👋

✗⃝🌍 *Date* : Dunia
     _${timeWib} Wib_
     _${timeWita} Wita_
     _${timeWit} Wit_ 
  

✗⃝🎩 Contak personel
${email}

✗⃝🍂 Github Owner
${ig}

✗⃝💫Creator Bot
@${owner} bh

┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
𒍮 _*NOTE USER BOT*_

*•This Whatsapp bot is still under development*

*If you are using Whatsapp Mod* 
  *Please Enter Command Like #allmenu*

*• And I thank you for* 
  *my team who have taught me about bots*
  
*• If you find a Bug*
  *Please contact Delevor Bot Whatsapp*`}

exports.sewa = (ucapanWaktu, botName, owner) => {
return `━━ *「 FAX BOT - INDO 」* ━━

DIN BOT - INDONESIA
└───────
  └ Sticker Maker, membuat sticker dari video atau gambar dalam waktu singkat
  └ Dengan menggunakan Din Bot kamu dapatkan" mendownload video atau audio dari youtube dengan sangat mudah
  └ Dengan menggunaka:n Din Bot kamu juga dapat mendownload video atau audio dari tiktok dengan sangat mudah

◩ *FREE USER*
└───────no,
 └✅ Bot on 24 jam 
 └❎ Unlimited Limit
 └❎ Premium User 
 └❎ Add Bot to Group 
   └❏ *Rp. ~0,00~*
 
◩ *PREMIUM*
└───────
 └✅ Bot on 24 jam 
 └✅ Unlimited Limit 
 └✅ Premium User 
 └❎ Add Bot to Group 
   └❏ *Rp. 10.000*
     └ Expired 30h
  
◩ *VIP - USER*
└───────
 └✅ Bcot on 24 jam 
 └✅ Unlimited Limit 
 └✅ Premium User 
 └✅ Add Bot to Group 
   └❏ *Rp. 20.000*
     └ Expired 30h

◩ *SO OWNER*
└───👾────
 └✅ Bot on 24 Jam 
 └✅ Change photos 
 └✅ Replace the boat name 
 └✅ Can be rented a 
   └❏ *Rp. 100.000*
     └ Expired 30h 
   
*MINAT CHAT OWNER DIN BOT*
@${owner}
`}
 
exports.rules = (prefix, sender) => {
    return `*w── 「 RULES 」 ──*

Hai kak @${sender.split("@")[0]}

1. Jangan spam bot. 
Sanksi: *WARN/SOFT BLOCK*

2. Jangan telepon bot.
Sanksi: *SOFT BLOCK*w

3. Jangan m(uxengeksploitasi bot.
Sanksi: *PERMANENT BLOCK*

Jika sudah dipahami rules-nya, silakan ketik *${prefix}.menu* untuk memulai!
`

}